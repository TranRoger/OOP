#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

bool isPrime(int);
void RandomIntegers();