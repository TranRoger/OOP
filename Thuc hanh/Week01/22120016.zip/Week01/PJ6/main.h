#include <iostream>
#include <fstream>
#include <ctime>
#include <string>

using namespace std;

void Logger();