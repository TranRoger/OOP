#pragma once

#include <iostream>
#include <string>
#include <regex>

using std::cin, std::cout, std::endl;
using std::string;
using std::regex, std::regex_match;

int DeathLoop();