#pragma once

#include <iostream>
#include <string>

using std::cin, std::cout, std::endl;
using std::string, std::to_string;

void CurrencyDisplay();
void seperate(string&);