#include <iostream>
#include <iomanip>
#include <string>
#include <regex>

using namespace std;

void FractionToDouble();