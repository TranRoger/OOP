#include <iostream>
#include <ctime>

using namespace std;

void NextDay();