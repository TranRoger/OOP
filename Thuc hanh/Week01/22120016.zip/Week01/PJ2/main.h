#pragma once

#include <iostream>
#include <string>

using std::cin, std::cout, std::endl;
using std::string;

bool WrongPassword(string);