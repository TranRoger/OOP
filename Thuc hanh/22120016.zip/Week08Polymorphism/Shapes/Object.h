#pragma once

#include <iostream>

class Object {
public:
    virtual std::string toString() = 0;
};
