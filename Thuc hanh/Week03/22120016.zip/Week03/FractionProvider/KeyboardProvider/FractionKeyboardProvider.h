#pragma once

#include <iostream>
#include "..\Fraction\Fraction.h"

class FractionKeyboardProvider {
public:
    static Fraction next();
};