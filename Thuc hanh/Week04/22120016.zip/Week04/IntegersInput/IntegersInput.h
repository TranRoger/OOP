#pragma once

#include <iostream>
using namespace std;

bool isPrime(const int&);